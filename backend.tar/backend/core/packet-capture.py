import scapy.all as scapy
import time
import json
import threading
import requests
from datetime import datetime
from scapy.layers.inet import IP, TCP, UDP
from scapy.layers.dns import DNS
from scapy.layers.l2 import Ether
import socket
from redis_config import redis_client
from config import Config
from settings import REMOTE_BLACKLIST_URL

# Atualizar função load_blacklist_whitelist
def load_blacklist_whitelist():
    """
    Carrega blacklist e whitelist dos arquivos definidos em Config.
    """
    try:
        with open(Config.BLACKLIST_FILE, 'r') as f:
            blacklist = set(line.strip() for line in f)
    except FileNotFoundError:
        blacklist = set()

    try:
        with open(Config.WHITELIST_FILE, 'r') as f:
            whitelist = set(line.strip() for line in f)
    except FileNotFoundError:
        whitelist = set()

    return blacklist, whitelist

# Atualizar função fetch_remote_blacklist
def fetch_remote_blacklist():
    """
    Busca a blacklist remota da URL definida em settings.
    """
    url = Config.REMOTE_BLACKLIST_URL
    try:
        response = requests.get(url)
        return set(response.text.splitlines())
    except Exception as e:
        print(f"Erro ao buscar blacklist remota: {e}")
        return set()

def reverse_dns(ip):
    try:
        return socket.gethostbyaddr(ip)[0]
    except socket.herror:
        return None

def process_packet(packet):
    if not packet.haslayer(IP):
        return

    data = {
        "timestamp": datetime.now().isoformat(),
        "src_ip": packet[IP].src,
        "dst_ip": packet[IP].dst,
        "protocol": packet[IP].proto,
        "length": len(packet),
        "mac_src": packet[Ether].src if packet.haslayer(Ether) else None,
        "mac_dst": packet[Ether].dst if packet.haslayer(Ether) else None,
    }

    # Portas e flags TCP/UDP
    if packet.haslayer(TCP):
        data.update({
            "src_port": packet[TCP].sport,
            "dst_port": packet[TCP].dport,
            "tcp_flags": packet[TCP].flags,
        })
    elif packet.haslayer(UDP):
        data.update({
            "src_port": packet[UDP].sport,
            "dst_port": packet[UDP].dport,
        })

    # DNS
    if packet.haslayer(DNS):
        dns_layer = packet[DNS]
        data.update({
            "dns_queries": dns_layer.qd.qname if dns_layer.qd else None,
            "fqdns": reverse_dns(packet[IP].dst),
        })

    # Payload
    data["payload"] = bytes(packet[IP].payload).hex() if packet.haslayer(IP) else None

    # Blacklist/Whitelist Check
    data["blacklist_flag"] = (data["src_ip"] in blacklist or data["dst_ip"] in blacklist)
    data["whitelist_flag"] = (data["src_ip"] in whitelist or data["dst_ip"] in whitelist)

    # Volume (bytes)
    data["bytes"] = len(packet)

    redis_client.rpush("network_packets", json.dumps(data))

def start_capture():
    print("Iniciando captura de pacotes...")
    scapy.sniff(prn=process_packet, store=False)

# Gerenciamento de backup
def save_backup():
    while True:
        time.sleep(3600)
        packets = redis_client.lrange("network_packets", 0, -1)
        redis_client.delete("network_packets")

        with open(f"backup/packets_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json", "w") as f:
            f.write(json.dumps([json.loads(packet) for packet in packets]))
        print("Backup salvo e enviado à API.")

if __name__ == "__main__":
    blacklist, whitelist = load_blacklist_whitelist()
    remote_blacklist = fetch_remote_blacklist()
    blacklist.update(remote_blacklist)

    threading.Thread(target=save_backup, daemon=True).start()
    start_capture()
