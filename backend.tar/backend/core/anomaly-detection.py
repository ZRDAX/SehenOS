import redis
import json
import pandas as pd
import time
import threading
from datetime import datetime
from anomaly_models import load_models
from preprocessing import preprocess_data
from config import Config
from redis_config import redis_client

# Buscar pacotes do Redis
def fetch_packets():
    packets = redis_client.lrange("network_packets", 0, -1)
    redis_client.delete("network_packets")
    return [json.loads(packet) for packet in packets]

# Salvar anomalias detectadas no Redis
def save_anomalies(df, isolation_preds, reconstruction_error):
    df["isolation_anomaly"] = isolation_preds == -1
    df["reconstruction_error"] = reconstruction_error
    anomalies = df[(df["isolation_anomaly"]) | (df["reconstruction_error"] > 0.01)]

    for anomaly in anomalies.to_dict(orient="records"):
        redis_client.rpush("network_anomalies", json.dumps(anomaly))
    print(f"{len(anomalies)} anomalias detectadas e salvas no Redis.")

# Gerenciamento de backup de anomalias
def save_backup():
    while True:
        time.sleep(7200)  # Backup a cada 2 horas
        anomalies = redis_client.lrange("network_anomalies", 0, -1)
        redis_client.delete("network_anomalies")

        backup_file = f"{Config.BACKUP_DIR}/anomalies_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        with open(backup_file, "w") as f:
            f.write(json.dumps([json.loads(anomaly) for anomaly in anomalies]))
        print(f"Backup de anomalias salvo: {backup_file}")

# Processamento contínuo
def process_packets(models):
    while True:
        packets = fetch_packets()
        if packets:
            # Pré-processar pacotes
            df, scaled_data = preprocess_data(packets)

            # Detectar anomalias
            isolation_preds, reconstruction_error = detect_anomalies(models, scaled_data)

            # Salvar anomalias detectadas
            save_anomalies(df, isolation_preds, reconstruction_error)
        time.sleep(5)  # Intervalo para evitar sobrecarga

# Função principal
if __name__ == "__main__":
    # Carregar modelos treinados
    models = load_models()

    # Iniciar thread de backup
    threading.Thread(target=save_backup, daemon=True).start()

    # Processamento contínuo
    process_packets(models)
