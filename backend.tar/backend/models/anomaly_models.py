import pickle
from sklearn.ensemble import IsolationForest
from sklearn.decomposition import PCA
from tensorflow.keras.models import Model, Sequential
from tensorflow.keras.layers import Input, Dense
from tensorflow.keras.models import load_model

# Treinar Isolation Forest
def train_isolation_forest(data, contamination=0.05):
    model = IsolationForest(contamination=contamination, random_state=42)
    model.fit(data)
    with open("models/pipes/isolation_forest.pkl", "wb") as f:
        pickle.dump(model, f)
    return model

# Treinar Autoencoder
def train_autoencoder(data, input_dim):
    autoencoder = Sequential([
        Input(shape=(input_dim,)),
        Dense(16, activation='relu'),
        Dense(8, activation='relu'),
        Dense(16, activation='relu'),
        Dense(input_dim, activation='linear')
    ])
    autoencoder.compile(optimizer='adam', loss='mse')
    autoencoder.fit(data, data, epochs=50, batch_size=32, verbose=1)
    autoencoder.save("models/pipes/autoencoder.h5")
    return autoencoder

# Treinar PCA
def train_pca(data, n_components=2):
    pca = PCA(n_components=n_components)
    pca.fit(data)
    with open("models/pipes/pca.pkl", "wb") as f:
        pickle.dump(pca, f)
    return pca

# Carregar modelos
def load_models():
    with open("models/pipes/isolation_forest.pkl", "rb") as f:
        isolation_forest = pickle.load(f)
    autoencoder = load_model("models/pipes/autoencoder.h5")
    with open("models/pipes/pca.pkl", "rb") as f:
        pca = pickle.load(f)
    return isolation_forest, autoencoder, pca
