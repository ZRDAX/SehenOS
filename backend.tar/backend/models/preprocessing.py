import pandas as pd
from sklearn.preprocessing import StandardScaler

# Função para preparar os dados
def preprocess_data(packets):
    """
    Preprocessa os dados dos pacotes capturados para análise.
    :param packets: Lista de pacotes em formato JSON.
    :return: DataFrame original e dados escalonados.
    """
    df = pd.DataFrame(packets)

    # Seleção de colunas relevantes
    numeric_cols = ["length", "src_port", "dst_port", "bytes"]
    df = df.fillna(0)  # Tratar valores nulos
    numeric_data = df[numeric_cols]

    # Escalonamento dos dados
    scaler = StandardScaler()
    scaled_data = scaler.fit_transform(numeric_data)

    return df, scaled_data
